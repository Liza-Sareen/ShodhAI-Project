const express = require("express");
const cors = require("cors");
const { exec } = require("child_process");

const app = express();
app.use(cors());
app.use(express.json());

// Mock Contests Data
const contests = [
  {
    id: 1,
    name: "Code Sprint 1",
    difficulty: "Easy",
    questions: [
      { id: 101, title: "Two Sum", description: "Find two numbers that add up to target." },
      { id: 102, title: "Palindrome Check", description: "Check if a string is palindrome." },
    ],
  },
  {
    id: 2,
    name: "Shodh-a-Code Challenge",
    difficulty: "Medium",
    questions: [
      { id: 201, title: "Reverse Linked List", description: "Reverse a given linked list." },
      { id: 202, title: "Maximum Subarray", description: "Find the maximum subarray sum." },
    ],
  },
];

// Mock Problems Data
const problems = {
  101: { id: 101, title: "Two Sum", description: "Find two numbers that add up to target." },
  102: { id: 102, title: "Palindrome Check", description: "Check if a string is palindrome." },
  201: { id: 201, title: "Reverse Linked List", description: "Reverse a linked list." },
  202: { id: 202, title: "Maximum Subarray", description: "Find the maximum sum subarray." },
};

// Routes
app.get("/api/contests", (req, res) => {
  res.json(contests);
});

app.get("/api/contests/:id", (req, res) => {
  const contest = contests.find(c => c.id === parseInt(req.params.id));
  if (!contest) return res.status(404).json({ message: "Contest not found" });
  res.json(contest);
});

app.get("/api/problems/:id", (req, res) => {
  const problem = problems[req.params.id];
  if (!problem) return res.status(404).json({ message: "Problem not found" });
  res.json(problem);
});

// Code Execution API
app.post("/api/run", (req, res) => {
  const { code } = req.body;

  exec(`echo "${code}" | node`, (error, stdout, stderr) => {
    if (error) {
      return res.json({ output: stderr || error.message });
    }
    res.json({ output: stdout || "Code ran successfully!" });
  });
});

const PORT = 5000;
app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
